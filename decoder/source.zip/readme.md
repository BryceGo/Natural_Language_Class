The answer is in evaluate.py

evaluate.py is the modified METEOR metric with N-gram, wordnet and stemming.


The other python code that was used to test in the report is in the folder called report_code. These programs were used to check for comparisons as described in the report.pdf

bleu.py is te BLEU metric
meteor.py is the baseline METEOR metric
meteor-ngram.py is the METEOR metric with N-gram only

hill_climb.py is the test used to tune my parameters. It's defaulted to run meteor.py. (Requires a folder called hill_results to run)





