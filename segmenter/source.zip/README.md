Bryce Golamco
bgolamco@sfu.ca

I followed the baseline algorithm but is currently getting around %55.45
